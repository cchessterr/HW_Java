package org.top.springpenprobe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPenProbeApplicationTests {

	@Test
	void contextLoads() {
	}

}
