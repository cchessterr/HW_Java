package org.top.springpenprobe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPenProbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPenProbeApplication.class, args);
	}

}
